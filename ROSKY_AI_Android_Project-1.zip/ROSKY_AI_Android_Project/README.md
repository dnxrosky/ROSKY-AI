# ROSKY AI Android project

This is an Android Studio project that wraps the current ROSKY AI HTML demo in an Android WebView.

## Build an APK with Android Studio
1. Install Android Studio and Android SDK Platform 35.
2. Open this folder as a project.
3. Let Gradle sync finish.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. The debug APK will be at `app/build/outputs/apk/debug/app-debug.apk`.

## Build using GitHub Actions
1. Upload this project to a GitHub repository on the `main` branch.
2. Open the repository's Actions tab.
3. Run `Build ROSKY AI APK` (or push to main).
4. Download the `ROSKY-AI-debug-APK` artifact from the workflow run.

## Important limitations
- This is a demo APK wrapper. The HTML currently uses a demo response and is NOT connected to Gemini yet.
- Admin panel, paid subscriptions, Google ads, login, and server-side security are visual/planning placeholders, not active services.
- Never put a Gemini API key directly in the APK. Add a secure backend first.
- This is a debug APK for testing, not a Play Store signed release.
